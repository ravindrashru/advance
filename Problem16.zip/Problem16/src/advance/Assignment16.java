package advance;

import java.util.Scanner;

public class Assignment16 {
	
	static int climbStairs(int N){
	    if ( N < 2 )
	        return 1;
	    else
	        return climbStairs(N-1) + climbStairs(N-2);
	}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		int res=Assignment16.climbStairs(num);
		System.out.println("Total distinct ways are: "+res);
		
		

	}

}
