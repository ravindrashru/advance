package problem6;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class problem6b {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		HashSet<Product> hset=new HashSet<Product>(); 
		Product p1=new Product("p001","pname1");
		Product p2=new Product("p002","pname2");
		Product p3=new Product("p003","pname3");
		Product p4=new Product("p004","pname4");
		Product p5=new Product("p005","pname5");
		Product p6=new Product("p006","pname6");
		Product p7=new Product("p007","pname7");
		Product p8=new Product("p008","pname8");
		Product p9=new Product("p009","pname9");
		Product p10=new Product("p0010","pname10");
		
		
		hset.add(p1); 
		hset.add(p2); 
		hset.add(p3); 
		hset.add(p4); 
		hset.add(p5); 
		hset.add(p6); 
		hset.add(p7); 
		hset.add(p8); 
		hset.add(p9); 
		hset.add(p10); 
		
		System.out.println("Enter the product Id to be searched");
		String pid=sc.next();
		
		if(hset.contains(pid)) {
			System.out.println("Product is vailable in list");
		}
		else {
			System.out.println("Product is vailable in list");
			
		}
		
		System.out.println("Enter the product Id to be remove");
		String pid1=sc.next();
		
		if(hset.remove(pid)) {
			System.out.println("Product is removed from the list");
		}
		else {
			System.out.println("Product is not removed from the list");
			
		}
		
	}

}

