package problem6;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class MainEmployee {

	LinkedList<Employee> ml = new LinkedList<Employee>();
	public static void main(String[] args) {
	MainEmployee m=new MainEmployee();
	m.addinput();
	m.display();

	}
	
	public void addinput() {
		
		Employee e1=new Employee(100,"abcd","xyz");
		Employee e2=new Employee(102,"pqrs","ploel");
		Employee e3=new Employee(98,"dsasd","sadasd");
		
		
		ml.add(e1);
		ml.add(e2);
		ml.add(e3);
		
	}
	
	public void display() {
		
	ListIterator itr=ml.listIterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	
	while (itr.hasPrevious()) {
        System.out.println(itr.previous());
    }
	
	}

}
