package problem6;

public class Employee {
	private int employeeNo;
	private String employeeName;
	private String Address;
	public int getEmployeeNo() {
		return employeeNo;
	}
	
	public Employee(int employeeNo, String employeeName, String address) {
		super();
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		Address = address;
	}

	@Override
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", employeeName=" + employeeName + ", Address=" + Address + "]";
	}
	

}
