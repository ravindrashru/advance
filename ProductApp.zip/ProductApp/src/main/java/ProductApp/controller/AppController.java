package ProductApp.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import ProductApp.Bean.Product;
import ProductApp.Dao.ProductDao;

@Controller
public class AppController {
	@Autowired
	private ProductDao productdao;
	
@RequestMapping("/")
	public String home(Model m) {
	List<Product> product=productdao.getProducts();
	m.addAttribute("product",product);
		return "index";	
	}
@RequestMapping("/addproduct")
	public  String addProduct(Model m) {
	m.addAttribute("title", "Add Product");
		return "addproductform";
	}
@RequestMapping("/delete/{productid}")
public  RedirectView deleteProduct(@PathVariable("productid") int productid, HttpServletRequest req) {
	productdao.deleteProduct(productid);
	RedirectView rd=new RedirectView();
	rd.setUrl(req.getContextPath()+  "/");
	return rd;
}
@RequestMapping("/update/{productid}")
public  String updateform(@PathVariable("productid") int pid, Model m) {
	Product product = new Product();
	m.addAttribute("product",product);
	return "updateform";
}


@RequestMapping(value="/handle-product",method = RequestMethod.POST)
public RedirectView handleProduct(@ModelAttribute Product product,HttpServletRequest req) {
	//System.out.println(product);
	productdao.createProduct(product);
	RedirectView rd=new RedirectView();
	rd.setUrl(req.getContextPath()+  "/");
	return rd;
}
}
