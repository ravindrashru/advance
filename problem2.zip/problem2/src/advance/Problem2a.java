package advance;

import java.util.Scanner;

public class Problem2a {

	public static void main(String[] args) {
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		str=sc.next();
		System.out.println("Length of the "+str+" is: "+str.length());
		System.out.println();
		System.out.println("Printing a entered string in uppercase");
		System.out.println(str.toUpperCase());
		System.out.println();
		
		String str1="";
		for (int i=0; i<str.length(); i++)
	      {
	         char ch= str.charAt(i); 
	        str1= ch+str1; 
	      }
		if(str1.equalsIgnoreCase(str)) {
			System.out.println(str+" is palindrome");
		}
		else {
			System.out.println(str+" is not palindrome");
		}
		

	}

}
