package advance;

import java.util.Random;

public class problem3a {

	public static void main(String[] args) {
		Instrument[] ins=new Instrument[10];
		Random rand = new Random();
	    
	    for (int i = 0; i < 10; i++) {
	    	int randomNum = rand.nextInt((3 - 1) + 1) + 1;
	    	
	    	if (randomNum == 1)
	    		ins[i] = new piano();
	    	else if (randomNum == 2)
	    		ins[i] = new Flute();
	    	else if (randomNum == 3)
	    		ins[i] = new Guitar();
	    	
	    	ins[i].play();
	    }
	    
	    for (int i = 0; i < 10; i++) {
	    	if (ins[i] instanceof piano) 
	    		System.out.println("Piano is stored at index " + i);
	    	else if (ins[i] instanceof Flute) 
	    		System.out.println("Flute is stored at index " + i);
	    	else if (ins[i] instanceof Guitar) 
	    		System.out.println("Guitar is stored at index " + i);
	    }

	}

}
