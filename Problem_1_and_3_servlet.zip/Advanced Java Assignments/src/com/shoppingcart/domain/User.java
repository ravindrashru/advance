package com.shoppingcart.domain;

public class User {
	private String first_name;
    private String adress ;
    private String email ;
    private String uname ;
    private String pass ;
    private String regdate;
	public User(String first_name, String adress, String email, String uname, String pass, String regdate) {
		super();
		this.first_name = first_name;
		this.adress = adress;
		this.email = email;
		this.uname = uname;
		this.pass = pass;
		this.regdate = regdate;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [first_name=" + first_name + ", adress=" + adress + ", email=" + email + ", uname="
				+ uname + ", pass=" + pass + ", regdate=" + regdate + "]";
	}
    
    
    
}
