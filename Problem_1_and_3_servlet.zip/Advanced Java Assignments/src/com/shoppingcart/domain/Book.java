package com.shoppingcart.domain;

public class Book {

	private int Book_Id;
	private String BookName;
	private String Author;
	private int Price;
	@Override
	public String toString() {
		return "Book [Book_Id=" + Book_Id + ", BookName=" + BookName + ", Author=" + Author + ", Price=" + Price + "]";
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(int book_Id, String bookName, String author, int price) {
		super();
		Book_Id = book_Id;
		BookName = bookName;
		Author = author;
		Price = price;
	}
	
}
