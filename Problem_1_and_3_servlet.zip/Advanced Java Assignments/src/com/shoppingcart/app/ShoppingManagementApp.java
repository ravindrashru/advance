package com.shoppingcart.app;

import java.util.Scanner;

import com.mycompany.dao.ProductManagmentDao;
import com.shoppingcart.dao.ShopManagmentDao;

public class ShoppingManagementApp {
	public static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) throws Exception {
		while (true) {
			System.out.println("Welcome to Shopping Cart.com please select any one: \n1. Books table \n2.User table\n3.Orders table");
			int option=sc.nextInt();
			if(1==option) {
			System.out.println(
					"Welcome to the Book management App, please select any one:\n 1. View Products\n 2. add Product\n 3. exit ");
			int sel = sc.nextInt();
			if (1 == sel) {
				ShopManagmentDao.query();
			} else if (2 == sel) {
				ShopManagmentDao.insert();
			}  else if (3 == sel) {
				System.err.println("Exit the system. ..\nSee you again");
				break;
			}
			}
			else if(2==option) {
			System.out.println(
					"Welcome to the Users management App, please select any one:\n 1. View Products\n 2. add Product\n 3. exit ");
			int sel1 = sc.nextInt();
			if (1 == sel1) {
				ShopManagmentDao.query1();
			} else if (2 == sel1) {
				ShopManagmentDao.insert1();
			}  else if (3 == sel1) {
				System.err.println("Exit the system. ..\nSee you again");
				break;
			}
			}
			else if(3==option) {
			System.out.println(
					"Welcome to the Orders_table management App, please select any one:\n 1. View Products\n 2. add Product\n 3. exit ");
			int sel2 = sc.nextInt();
			if (1 == sel2) {
				ShopManagmentDao.query2();
			} else if (2 == sel2) {
				ShopManagmentDao.insert2();
			}  else if (3 == sel2) {
				System.err.println("Exit the system. ..\nSee you again");
				break;
			}
			}
		}
	}
}
