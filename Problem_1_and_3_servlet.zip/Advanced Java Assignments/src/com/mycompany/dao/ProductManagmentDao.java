package com.mycompany.dao;

import java.io.DataInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.mycompany.dbutil.DBUtil;

public class ProductManagmentDao {
	static Scanner sc = new Scanner(System.in);

	public static void query() throws Exception {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from Product order by ProductId asc";
		Statement st = conn.createStatement();
		ResultSet rt = st.executeQuery(sql);
		System.out.println("ID" + "\t" + "name" + "\t" + "price");
		while (rt.next()) {
			System.err.println(rt.getString("ProductId") + "\t" + rt.getString("ProductName") + "\t "
					+ rt.getString("ProductPrice"));
		}
	}

	public static void insert() throws Exception {
		Connection conn = DBUtil.getConnection();
	
		DataInputStream KB = new DataInputStream(System.in);

	
		System.out.print("Enter Product ID: ");
		String Pid = KB.readLine();
		
		System.out.print("Enter Product Name: ");
		String Pn = KB.readLine();
	
		System.out.print("Enter Product Price: ");
		String Pp = KB.readLine();

		PreparedStatement smt = conn.prepareStatement("insert into Product values(?,?,?)");

		
		smt.setInt(1, Integer.parseInt(Pid));
		smt.setString(2, Pn);
		smt.setInt(3, Integer.parseInt(Pp));
		smt.executeUpdate();

	}

	
	public static void delete() throws Exception {
		StringBuffer sbf = new StringBuffer();
		Connection conn = DBUtil.getConnection();
		System.out.println("Please enter the Product ID to be deleted");
		int id = sc.nextInt();
		String sql = "DELETE FROM Product WHERE ProductId= ";
		sbf.append(sql);
		sbf.append(id);
		Statement st = conn.createStatement();
		int n = st.executeUpdate(sbf.toString());
		if (n > 0) {
			System.out.println("Delete successfully!");
		} else {
			System.out.println("The id does not exist");
		}
	}

	public static void update() throws Exception {
	        Connection conn = DBUtil.getConnection();
	        System.out.println("Please enter the Product ID to be modified");
	        int uid = sc.nextInt();
	        StringBuffer sbf = new StringBuffer();
	        String sql = "select * from Product where ProductId=" + uid;
	        Statement st1 = conn.createStatement();
	        ResultSet rt = st1.executeQuery(sql);
	        boolean a = false;
	        while (rt.next()) {
	            if (rt.getInt("ProductId") == uid) {
	                a = true;
	                break;
	            }
	        }
	        if (a) {
	            System.out.println("Please enter the Product name" );
	            String name = sc.next();
	            System.out.println("Please enter the Product price"); 
	            int price = sc.nextInt();
	            String sqll = "UPDATE Product SET ProductName = ?, ProductPrice=? WHERE ProductId = ?";
	            PreparedStatement pstmt = conn.prepareStatement(sqll);
	            		
	            	String Productname = name;
	            	int ProductPrice = price;
	                int id = uid;
	                pstmt.setString(1, Productname);
	                pstmt.setInt(2, ProductPrice);
	                pstmt.setInt(3, id);
	                pstmt.executeUpdate();
	                System.out.println("Modified successfully!");
				
	        }
	        else {
	        	
		            System.out.println("Modification failed!");
		        
	        }
	}
	public static void searchById() throws Exception {
		Connection conn = DBUtil.getConnection();
		System.out.println("Please enter the ProductID information to be seen");
		String information = sc.next();
		StringBuffer sbf = new StringBuffer();
		String sql = "SELECT * FROM Product WHERE ProductId LIKE";
		sbf.append(sql);
		sbf.append("'%");
		sbf.append(information);
		sbf.append("%'");
		Statement st1 = conn.createStatement();
		boolean a = false;
		ResultSet rt = st1.executeQuery(sbf.toString());
		while (rt.next()) {
			if (rt.getString("ProductId") != null) {
				System.out.println("ID" + "\t" + "name" + "\t" + "price");
				System.err.println(rt.getString("ProductId") + "\t" + rt.getString("ProductName") + "\t"
						+ rt.getString("ProductPrice"));
				a = true;
				break;
			}
		}
		if (!a) {
			System.out.println("No record....");
		}
	}

	public static void myexit() {
		System.exit(0);
	}
}
