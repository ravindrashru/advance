package com.mycompany.app;

import java.util.Scanner;

import com.mycompany.dao.ProductManagmentDao;

public class ProductManagementApp {
	public static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) throws Exception {
		while (true) {
			System.out.println(
					"Welcome to the Product management App, please select any one:\n 1. View Products\n 2. add Product\n 3. Update Product\n 4. Delete Product\n 5, Search Product\n 6. exit ");
			int sel = sc.nextInt();
			if (1 == sel) {
				ProductManagmentDao.query();
			} else if (2 == sel) {
				ProductManagmentDao.insert();
			} else if (3 == sel) {
				ProductManagmentDao.update();
			} else if (4 == sel) {
				ProductManagmentDao.delete();
			} else if (5 == sel) {
				ProductManagmentDao.searchById();
			} else if (6 == sel) {
				System.err.println("Exit the system. ..\nSee you again");
				break;
			}
		}
	}
}
