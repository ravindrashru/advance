package problem1;

public class MainOf_Modify_Recat {

	public static void main(String[] args) {
		Rectangle_Modify rm=new Rectangle_Modify();
		rm.setLength(40);
		rm.setBreadth(10);
		rm.areaRectangle();
		rm.perimeterRectangle();
		rm.display();

	}

}
