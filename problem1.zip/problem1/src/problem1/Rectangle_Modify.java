package problem1;

public class Rectangle_Modify {
	private float length;
	private float breadth;
	float area,perimeter;
	
	public Rectangle_Modify() {
		length=1;
		breadth=1;
		
	}

	public float getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public float getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	
	 void  areaRectangle()
	    {
	        area = length * breadth;
	       
	    }
	 
	     void  perimeterRectangle()
	    {
	    	 perimeter = 2*(length + breadth);
	       
	    }

	    void display() {
	    	if(length>0.0 && length<20.0)
	        {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Parameter of Rectangle = " +perimeter);
	       
	        }
	    else {
	    	System.out.println("length and breadth should be in range 0 and 20");
	    }
	    
}
}
	
	


