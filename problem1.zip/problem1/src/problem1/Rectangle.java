package problem1;

import java.util.Scanner;

public class Rectangle {
	private int length ;
	private int breadth;
			int area;
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	
	public Rectangle(){
		length=0;
		breadth=0;
	}
	
	    void calculate() {
	        area = length * breadth;
	        
	    }

	    void display() {
	    	 System.out.println("length of Rectangle = " + length);
	    	 System.out.println("breadth of Rectangle = " + breadth);
	        System.out.println("Area of Rectangle = " + area);
	       
	    }

}
