package problem1;

public class ReactangleMain {

	public static void main(String[] args) {
		Rectangle rect=new Rectangle();
		rect.setBreadth(100);
		rect.setLength(1);
		rect.calculate();
		rect.display();
		System.out.println("-------------");
		
		Rectangle rect1=new Rectangle();
		rect1.setBreadth(200);
		rect1.setLength(1);
		rect1.calculate();
		rect1.display();
		System.out.println("-------------");
		
		Rectangle rect3=new Rectangle();
		rect3.setBreadth(300);
		rect3.setLength(1);
		rect3.calculate();
		rect3.display();
		System.out.println("-------------");

	}

}
