package advance;

public class Problem5b {

	public static void main(String[] args) {
		String str ="23 + 45 - ( 343 / 12 )";
		String[] stringarray = str.split(" ");   
		//iterate over string array  
		for(int i=0; i< stringarray.length; i++)  
		{  
		//prints the tokens  
		System.out.println(stringarray[i]);  

	}

	}
}
